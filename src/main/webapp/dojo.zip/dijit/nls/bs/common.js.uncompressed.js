define("dijit/nls/bs/common", {      
//begin v1.x content
	buttonOk: "OK",
	buttonCancel: "Odustani",
	buttonSave: "Spremi",
	itemClose: "Zatvori"
//end v1.x content
});

