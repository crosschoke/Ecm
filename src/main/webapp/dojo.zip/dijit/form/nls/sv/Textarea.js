//>>built
define("dijit/form/nls/sv/Textarea",({iframeEditTitle:"redigeringsområde",iframeFocusTitle:"redigeringsområdesram"}));
