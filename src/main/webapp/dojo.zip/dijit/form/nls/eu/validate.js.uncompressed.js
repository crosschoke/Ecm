define("dijit/form/nls/eu/validate", {      
//begin v1.x content
	invalidMessage: "Sartutako balioak ez du balio.",
	missingMessage: "Balio hau beharrezkoa da.",
	rangeMessage: "Balio hau barrutitik kanpora dago."
//end v1.x content
});

