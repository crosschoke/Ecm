define(
"dijit/form/nls/th/ComboBox", ({
		previousMessage: "การเลือกก่อนหน้า",
		nextMessage: "การเลือกเพิ่มเติม"
})
);
