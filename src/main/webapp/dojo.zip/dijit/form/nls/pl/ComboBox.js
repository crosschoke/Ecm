//>>built
define("dijit/form/nls/pl/ComboBox",({previousMessage:"Poprzednie wybory",nextMessage:"Więcej wyborów"}));
